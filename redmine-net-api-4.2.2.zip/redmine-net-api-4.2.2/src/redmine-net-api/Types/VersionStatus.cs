﻿namespace Redmine.Net.Api.Types
{
    /// <summary>
    /// 
    /// </summary>
    public enum VersionStatus
    {
        /// <summary>
        /// 
        /// </summary>
        Open = 1,
        /// <summary>
        /// 
        /// </summary>
        Locked,
        /// <summary>
        /// 
        /// </summary>
        Closed
    }
}