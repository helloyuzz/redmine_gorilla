﻿namespace Redmine.Net.Api.Types
{
    /// <summary>
    /// 
    /// </summary>
    public enum VersionSharing
    {
        /// <summary>
        /// 
        /// </summary>
        None = 1,
        /// <summary>
        /// 
        /// </summary>
        Descendants,
        /// <summary>
        /// 
        /// </summary>
        Hierarchy,
        /// <summary>
        /// 
        /// </summary>
        Tree,
        /// <summary>
        /// 
        /// </summary>
        System
    }
}