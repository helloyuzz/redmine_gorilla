namespace Redmine.Net.Api
{
    /// <summary>
    /// 
    /// </summary>
    public enum RedirectType
    {
        /// <summary>
        /// 
        /// </summary>
        None,
        /// <summary>
        /// 
        /// </summary>
        OnlyHost,
        /// <summary>
        /// 
        /// </summary>
        All
    };
}